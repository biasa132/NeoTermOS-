import os

class VFS:
    def __init__(self, root):
        self.ROOT = os.path.abspath(root)
        self.cwd = self.ROOT

    def resolve(self, path):
        target = os.path.abspath(os.path.join(self.cwd, path))
        if not target.startswith(self.ROOT):
            raise PermissionError("VFS escape blocked")
        return target

    def cd(self, path):
        target = self.resolve(path)
        if os.path.isdir(target):
            self.cwd = target
        else:
            raise FileNotFoundError("Directory not found")

    def ls(self):
        return os.listdir(self.cwd)

    def pwd(self):
        rel = self.cwd.replace(self.ROOT, "")
        return "/" if rel == "" else rel

    def read(self, path):
        with open(self.resolve(path), "r") as f:
            return f.read()

    def write(self, path, data):
        with open(self.resolve(path), "w") as f:
            f.write(data)
