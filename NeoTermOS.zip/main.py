#!/usr/bin/env python3
import os, sys, json, time, subprocess, getpass, uuid, socket, shutil, signal, threading

# =========================
# ROOT & PATH
# =========================
ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin")
USR_BIN = os.path.join(ROOT, "usr", "bin")
ETC = os.path.join(ROOT, "etc")
LOCK_DIR = os.path.join(ETC, "locks")
os.makedirs(LOCK_DIR, exist_ok=True)
os.environ["PATH"] = f"{BIN}:{USR_BIN}:" + os.environ.get("PATH", "")

USERS_DB = os.path.join(ETC, "users.json")
SSH_DB   = os.path.join(ETC, "ssh.json")

# =========================
# INIT DATABASE
# =========================
if not os.path.exists(USERS_DB):
    with open(USERS_DB, "w") as f:
        json.dump({
            "root": {"username":"root","password":"root","uuid":0,"role":"root"}
        }, f, indent=2)

if not os.path.exists(SSH_DB):
    with open(SSH_DB, "w") as f:
        json.dump({}, f, indent=2)

USERS = json.load(open(USERS_DB))
SSH_USERS = json.load(open(SSH_DB))

# =========================
# UTIL FUNCTIONS
# =========================
def save_users():
    json.dump(USERS, open(USERS_DB, "w"), indent=2)

def save_ssh():
    json.dump(SSH_USERS, open(SSH_DB, "w"), indent=2)

def detect_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

def start_sshd():
    subprocess.run("pkill sshd 2>/dev/null", shell=True)
    subprocess.run("pkill dropbear 2>/dev/null", shell=True)
    if shutil.which("dropbear"):
        subprocess.run("dropbear -R -E -p 2222", shell=True)
        print("[SSH] Dropbear running on port 2222")
    elif shutil.which("sshd"):
        subprocess.run("sshd -p 2222", shell=True)
        print("[SSH] OpenSSH running on port 2222")
    else:
        print("[SSH] No SSH server installed")

def is_user_logged_in(username):
    return os.path.exists(os.path.join(LOCK_DIR, f"{username}.lock"))

def set_user_logged_in(username):
    open(os.path.join(LOCK_DIR, f"{username}.lock"), "w").close()

def set_user_logged_out(username):
    f = os.path.join(LOCK_DIR, f"{username}.lock")
    if os.path.exists(f): os.remove(f)

# =========================
# CENTERED LOGIN (LOCAL)
# =========================
def centered_login():
    os.system("clear")
    cols, rows = shutil.get_terminal_size((80,24))
    lines = ["="*40,"      Welcome to NeoTermOS      ","="*40,"","   Please login   ",""]
    print("\n" * ((rows - len(lines)) // 2))
    for l in lines: print(l.center(cols))

# =========================
# LOGIN (LOCAL TERMINAL)
# =========================
def login():
    centered_login()
    for _ in range(3):
        u = input("username: ").strip()
        p = getpass.getpass("password: ")
        user = USERS.get(u)
        if user and user["password"] == p:
            if is_user_logged_in(u):
                print("[LOGIN] User already logged in ❌")
                continue
            set_user_logged_in(u)
            return user
        print("Login incorrect\n")
    sys.exit(1)

# =========================
# DETECT SSH MODE
# =========================
SSH_MODE = "--ssh" in sys.argv or os.environ.get("NEOTERMOS_SSH")=="1"

if SSH_MODE:
    # SSH mode hanya untuk root
    USERNAME = os.environ.get("USER","root")
    CURRENT_USER = USERS.get(USERNAME)
    if not CURRENT_USER:
        sys.exit("[SSH] User not registered in NeoTermOS")
else:
    CURRENT_USER = login()
    USERNAME = CURRENT_USER["username"]

IS_ROOT = CURRENT_USER["role"]=="root"

# =========================
# PROMPT
# =========================
def prompt(vfs=None):
    sym = "#" if CURRENT_USER["role"]=="root" else "$"
    path = vfs.pwd() if vfs else ""
    return f"NeoTermOS:{USERNAME}{sym}{path} "

# =========================
# EXEC & SUDO
# =========================
def exec_cmd(cmd):
    env = os.environ.copy()
    env["PATH"] = f"{BIN}:{USR_BIN}:" + env.get("PATH","")
    subprocess.run(cmd, shell=True, env=env)

def sudo_exec(cmd):
    if CURRENT_USER["role"]=="root": return exec_cmd(cmd)
    pw = getpass.getpass("[sudo] password for root: ")
    if pw != USERS["root"]["password"]:
        print("Wrong password"); return
    exec_cmd(cmd)

# =========================
# SSH CREATE (TERMINAL ONLY)
# =========================
def ssh_create():
    if SSH_MODE:
        print("ssh-create hanya bisa dijalankan di terminal lokal ❌")
        return
    if not IS_ROOT and USERNAME in SSH_USERS:
        print("SSH untuk user ini sudah ada ❌"); return
    start_sshd()
    subprocess.run(f"useradd -m {USERNAME}", shell=True, stderr=subprocess.DEVNULL)
    subprocess.run(f"echo '{USERNAME}:{CURRENT_USER['password']}' | chpasswd", shell=True)
    shell_path = os.path.join(ROOT, "main.py")
    subprocess.run(["chsh","-s",shell_path, USERNAME], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    SSH_USERS[USERNAME] = {"port":2222,"created":int(time.time())}
    save_ssh()
    ip = detect_ip()
    print("\033[1;32mSSH READY (REAL)\033[0m")
    print(f"ssh {USERNAME}@{ip} -p 2222")
    print("Password sama dengan NeoTermOS\n")

# =========================
# INIT VFS & NEO PKG
# =========================
from vfs.vfs import VFS
from pkg.neopkg import NeoPkg
vfs = VFS(ROOT)
neopkg = NeoPkg(ROOT)

print("\033[1;32mNeoTermOS — Kernel Online\033[0m")

# =========================
# MAIN SHELL LOOP
# =========================
if SSH_MODE:
    # SSH USER SHELL
    def get_ssh_prompt(user):
        sym = "#" if user["role"]=="root" else "$"
        return f"NeoTermOS:({user['username']}){sym}/ "

    def ssh_shell():
        print(f"SSH mode detected. Welcome {USERNAME}")
        while True:
            try:
                cmd = input(get_ssh_prompt(CURRENT_USER)).strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not cmd: continue
            if cmd in ("exit","quit"): break
            if cmd=="ssh-create":
                print("ssh-create tidak bisa dijalankan lewat SSH ❌"); continue
            parts = cmd.split()
            if parts[0]=="sudo": sudo_exec(" ".join(parts[1:]))
            elif parts[0]=="neo":
                if len(parts)==1: print("neo add <repo>\nneo update\nneo list\nneo search <pkg>\nneo down <pkg>")
                elif parts[1]=="add" and len(parts)==3: neopkg.add(parts[2])
                elif parts[1]=="update": neopkg.update()
                elif parts[1]=="list": neopkg.list()
                elif parts[1]=="search" and len(parts)==3: neopkg.search(parts[2])
                elif parts[1]=="down" and len(parts)==3: neopkg.down(parts[2])
                else: print("Unknown neo command")
            else:
                exec_cmd(cmd)
    ssh_shell()

else:
    # TERMINAL SHELL
    while True:
        try:
            cmd = input(prompt(vfs)).strip()
        except (EOFError, KeyboardInterrupt):
            print(); break
        if not cmd: continue
        parts = cmd.split()
        if cmd in ("exit","quit"):
            set_user_logged_out(USERNAME)
            break
        elif cmd=="pwd": print(vfs.pwd())
        elif cmd=="ls":
            for f in vfs.ls(): print(f)
        elif cmd=="ssh-create": ssh_create()
        elif cmd.startswith("cd "):
            try: vfs.cd(cmd[3:].strip())
            except Exception as e: print(e)
        elif parts[0]=="sudo": sudo_exec(" ".join(parts[1:]))
        elif parts[0]=="neo":
            if len(parts)==1: print("neo add <repo>\nneo update\nneo list\nneo search <pkg>\nneo down <pkg>")
            elif parts[1]=="add" and len(parts)==3: neopkg.add(parts[2])
            elif parts[1]=="update": neopkg.update()
            elif parts[1]=="list": neopkg.list()
            elif parts[1]=="search" and len(parts)==3: neopkg.search(parts[2])
            elif parts[1]=="down" and len(parts)==3: neopkg.down(parts[2])
            else: print("Unknown neo command")
        else:
            exec_cmd(cmd)
